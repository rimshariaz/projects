from datetime import date

from team import Team


class UserInterface:
    def __init__(self, fee=200):
        # In this list we will store all the teams.
        # Initially the list is empty.
        self.__teams = []

        # A fee variable that holds the fee that each team must pay to participate in the event.
        self.__fee = fee

    # Method to get the next ID for a Team object.
    def get_next_id(self):
        # If the first team is being created, the ID will be 1.
        if len(self.__teams) == 0:
            return 1
        else:
            # Get the maximum ID from the team list.
            new_id = max(self.__teams, key=lambda team: team.get_id())
            if new_id:
                # The new ID will be the maximum in the list + 1
                return new_id.get_id() + 1
            else:
                return 1

    # Method for creating new team.
    def create_team(self):
        print("\n\t\tREGISTERING NEW TEAM:")

        # Create an infinite loop for entering team name.
        # The loop will end when the user enters a valid value, not empty line.
        while True:
            name = str(input("Enter team name: ")).strip()  # Use strip() in case the user enters trailing spaces.
            if name:
                break

        # Create an infinite loop for entering team type.
        # The loop will end when the user enters a valid value - boys/girls.
        while True:
            # Use strip() in case the user enters trailing spaces.
            # Use lower() to convert to lower case(), in case user enters 'Boys' or 'BOYs'
            type_ = str(input("Team type (boys/girls): ")).strip().lower()
            if type_ != "boys" and type_ != "girls":
                print("Wrong input!")
            else:
                break

        # Create an infinite loop for entering Team paid the fee.
        # The loop will end when the user enters a valid value - Y or N.
        while True:
            is_fee_paid = str(input("Did the team pay the fee? (Y/N) ")).strip().upper()
            if is_fee_paid != "Y" and is_fee_paid != "N":
                print("Wrong input!")
            else:
                if is_fee_paid == "Y":
                    is_fee_paid = True
                else:
                    is_fee_paid = False
                break

        # Get the new ID for the current team to be created
        id_ = self.get_next_id()

        # Get the today's date
        today = date.today()

        # Create new Team object
        new_team = Team(id_, today, name, type_, is_fee_paid)

        # Add the Team object to the list
        self.__teams.append(new_team)

        print(f"\n>> Team '{name}' registered successfully!")

    def update_team(self):
        # This variable will track user changes to a Team object
        change_made = False

        # Use try/catch in case of possible errors
        try:
            id_ = int(input("\nEnter team ID: "))
            # Using List comprehension, search in the list the team with this ID
            team_found = [team for team in self.__teams if team.get_id() == id_]

            # If found:
            if team_found:
                # The result is a list with 1 element, so consider only this one.
                team_found = team_found[0]
                print(f"\n\t\tUPDATE TEAM ID {team_found.get_id()}")

                # Print the current team name
                print(f"Name: {team_found.get_name()}")

                # Give the option to leave the current name
                new_name = str(input("Enter new team name (leave space to skip): ")).strip()
                if new_name:
                    change_made = True
                    team_found.set_name(new_name)

                # Print the current team type
                print(f"Type: {team_found.get_type()}")
                while True:
                    # Give the option to leave the current name
                    new_type = str(input("Enter new team type (boys/girls) (leave space to skip): ")).strip().lower()
                    if new_type != "boys" and new_type != "girls" and new_type:
                        print("Wrong input!")
                    elif not new_type:
                        break
                    else:
                        change_made = True
                        team_found.set_type(new_type)
                        break

                # If there are any changes to the team:
                if change_made:
                    # Give the option to the user to confirm the change:
                    confirm = str(input("Confirm the change? (Y/N): ")).strip().upper()
                    if confirm == "Y":
                        # Search the team in the list
                        for i in range(len(self.__teams)):
                            if self.__teams[i].get_id() == team_found.get_id():
                                # And replace with object changed.
                                self.__teams[i] = team_found
                                break
                        print("TEAM UPDATED SUCCESSFULLY!")
                    else:
                        print("NO CHANGE HAS BEEN MADE.")

            else:
                print(f">> Team with ID {id_} not found!")
        except:
            print(">> Wrong team ID!")

    # Method to pay a fee for a team.
    def pay_fee(self):
        # Use try/catch in case of possible errors
        try:
            id_ = int(input("\nEnter team ID: "))
            # Using List comprehension, search in the list the team with this ID
            team_found = [team for team in self.__teams if team.get_id() == id_]
            if team_found:
                # The result is a list with 1 element, so consider only this one.
                team_found = team_found[0]

                # Check if this team has already paid the fee:
                if team_found.get_fee_paid():
                    print(f"\nTeam '{team_found.get_name()}' has already paid the fee.")
                else:
                    # Give the option to the user to confirm the change:
                    confirm = str(input("Confirm fee paid? (Y/N): ")).strip().upper()
                    if confirm == "Y":
                        team_found.set_fee_paid(True)
                        for i in range(len(self.__teams)):
                            if self.__teams[i].get_id() == team_found.get_id():
                                self.__teams[i] = team_found
                                break
                        print("FEE PAID SUCCESSFULLY!")
                    else:
                        print("NO CHANGE HAS BEEN MADE.")

            else:
                print(f">> Team with ID {id_} not found!")
        except:
            print(">> Wrong team ID!")

    def cancel_team_participation(self):
        # Use try/catch in case of possible errors
        try:
            id_ = int(input("\nEnter team ID: "))
            # Using List comprehension, search in the list the team with this ID
            team_found = [team for team in self.__teams if team.get_id() == id_]

            if team_found:
                # The result is a list with 1 element, so consider only this one:
                team_found = team_found[0]

                # Check if this team has already cancelled the participation:
                if team_found.get_cancel_date():
                    print(f"\nTeam '{team_found.get_name()}' has already cancelled the participation.'")
                else:
                    # Give the option to the user to confirm the change:
                    confirm = str(input(
                        f"Confirm cancelling the participation for '{team_found.get_name()}'? (Y/N): ")).strip().upper()
                    if confirm == "Y":
                        team_found.set_cancel_date(date.today())
                        for i in range(len(self.__teams)):
                            if self.__teams[i].get_id() == team_found.get_id():
                                self.__teams[i] = team_found
                                break
                        print(f"PARTICIPATION CANCELLED FOR TEAM '{team_found.get_name()}'!")
                    else:
                        print("NO CHANGE HAS BEEN MADE.")

            else:
                print(f">> Team with ID {id_} not found!")
        except:
            print(">> Wrong team ID!")

    def print_team_by_id(self):
        # Use try/catch in case of possible errors
        try:
            id_ = int(input("\nEnter team ID: "))
            # Using List comprehension, search in the list the team with this ID:
            team_found = [team for team in self.__teams if team.get_id() == id_]
            if team_found:
                print("------------------------------------")
                # The result is a list with 1 element, so consider only this one:
                print(team_found[0], end="")
                print("------------------------------------")
            else:
                print(f">> Team with ID {id_} not found!")
        except:
            print(">> Wrong team ID!")

    def delete_team(self):
        # Use try/catch in case of possible errors
        try:
            id_ = int(input("\nEnter team ID: "))
            # Using List comprehension, search in the list the team with this ID:
            team_found = [team for team in self.__teams if team.get_id() == id_]

            if team_found:
                # The result is a list with 1 element, so consider only this one:
                team_found = team_found[0]
                print(f"Team with ID {team_found.get_id()} found.")

                # Give the option to the user to confirm the change:
                confirm = str(input(f"Confirm deletion for '{team_found.get_name()}'? (Y/N): ")).strip().upper()
                if confirm == "Y":
                    # Using List comprehension, filter the list by deleting the team with that ID
                    self.__teams = [team for team in self.__teams if team.get_id() != id_]
                    print(f"TEAM {team_found.get_name()} DELETED!")
                else:
                    print("NO CHANGE HAS BEEN MADE.")
            else:
                print(f">> Team with ID {id_} not found!")
        except:
            print(">> Wrong team ID!")

    def print_all_teams(self):
        print(f"\n\t\tALL TEAMS LIST ({len(self.__teams)})")
        if self.__teams:
            print("------------------------------------")
            for team in self.__teams:
                # Because we implemented the method __str__() in class Team, we can simply use team object in method print()
                print(team, end="")
                print("------------------------------------")
        else:
            print("\n>> There are no teams registered!")

    def print_team_by_type(self):
        # Create an infinite loop for entering team type.
        # The loop will end when the user enters a valid value - boys/girls.
        while True:
            type_ = str(input("\nTeam type (boys/girls): ")).strip().lower()
            if type_ != "boys" and type_ != "girls":
                print("Wrong input!")
            else:
                break

        # Using List comprehension, search in the list the teams with this type:
        teams_found = [team for team in self.__teams if team.get_type() == type_]
        print(f"\n\t\t{type_.upper()} TEAMS LIST ({len(teams_found)})")

        if teams_found:
            print("------------------------------------")
            for team in teams_found:
                print(team, end="")
                print("------------------------------------")
        else:
            print("\n>> There are no teams found!")

    def print_fee_amount(self):
        # Using List comprehension, get the teams that paid the fee:
        fee_paid_count = len([team for team in self.__teams if team.get_fee_paid()])
        amount = fee_paid_count * self.__fee
        print(f"\n${amount} ACCUMULATED FROM FEES.")

    def print_menu(self):
        print("\n\t\tMENU")
        print("1. Register new team")
        print("2. Read a team by ID")
        print("3. Read teams by type (boys or girls)")
        print("4. Read all teams in a list")
        print("5. Update a team")
        print("6. Delete a team")
        print("7. Set fee paid for a team")
        print("8. Cancel team participation")
        print("9. Number of teams")
        print("10. Percent of teams that has paid their fee")
        print("11. Store the information about all the teams to a text file")
        print("12. Read the information about all the teams from a text file")
        print("13. Accumulated amount from fees")
        print("0. Exit the program")

    def print_teams_number(self):
        count = len(self.__teams)
        print(f"\nTHERE ARE {count} TEAM(S) AT THE MOMENT.\n")

    def print_fee_paid_percent(self):
        # Using List comprehension, get the teams that paid the fee:
        fee_paid_count = len([team for team in self.__teams if team.get_fee_paid()])

        # Number of teams
        teams_number = len(self.__teams)
        if teams_number == 0:
            percent = 0
        else:
            # Calculate the percentage
            percent = (fee_paid_count / teams_number) * 100.0
        print(f"\n{percent}% OF TEAMS PAID THEIR FEE")

    def store_data_to_file(self):
        if len(self.__teams) == 0:
            print("\nThere are no teams data to write!\n")
        else:
            # Use block try/catch in case of any error
            try:
                # Open the file for writing
                with open('teams.txt', 'w') as file:
                    # Loop the TEAM list and write the file line-by-line
                    for team in self.__teams:
                        file.write(team.get_data_for_file())
                        # Add new line
                        file.write("\n")
                print("\nData written successfully!\n")
            except:
                print("\nAN ERROR OCCURRED!\n")

    def read_data_from_file(self):
        # Use block try/catch in case of any error
        try:
            # Open the file for reading
            with open('teams.txt') as file:
                # Read all the lines in a list.
                file_content = file.readlines()

            if len(file_content) > 0:
                # If the file contains any data, clear the current list:
                self.__teams.clear()

                # The list file_content contains strings
                for line in file_content:
                    # Get rid of new line characters and any trailing spaces
                    line = line.replace("\n", "").strip()

                    # The values (id, name, etc..) are separated by comma.
                    # Split the string into a list.
                    values = line.split(",")
                    id_ = int(values[0])
                    date_ = values[1]
                    name_ = values[2]
                    type_ = values[3]

                    if values[4] == 'True':
                        fee_paid = True
                    else:
                        fee_paid = False
                    cancel_date = values[5]

                    # Create a Team object
                    team = Team(id_, date_, name_, type_, fee_paid)
                    if cancel_date != 'None':
                        team.set_cancel_date(cancel_date)

                    # Include the Team object in the list
                    self.__teams.append(team)
                print("\nData read successfully!\n")
            else:
                print("\nThe file is empty!\n")
        except:
            print("\nAN ERROR OCCURRED!\n")

    # Start hockey teams management.
    def start(self):
        # Infinite loop, the user can exit by pressing '0'.
        while True:
            # Print the available menu items
            self.print_menu()
            user_choice = -1

            # Use try/catch in case user enters a non-integer value
            try:
                user_choice = int(input("  your choice: "))
            except:
                pass

            # In case of user choice, do the corresponding action.
            # To each action is linked a corresponding method.
            if user_choice == 1:
                self.create_team()
            elif user_choice == 2:
                self.print_team_by_id()
            elif user_choice == 3:
                self.print_team_by_type()
            elif user_choice == 4:
                self.print_all_teams()
            elif user_choice == 5:
                self.update_team()
            elif user_choice == 6:
                self.delete_team()
            elif user_choice == 7:
                self.pay_fee()
            elif user_choice == 8:
                self.cancel_team_participation()
            elif user_choice == 9:
                self.print_teams_number()
            elif user_choice == 10:
                self.print_fee_paid_percent()
            elif user_choice == 11:
                self.store_data_to_file()
            elif user_choice == 12:
                self.read_data_from_file()
            elif user_choice == 13:
                self.print_fee_amount()
            elif user_choice == 0:
                print("Done.")
                break
            else:
                print("WRONG OPTION! TRY ANOTHER!")
