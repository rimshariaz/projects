class Team:
    # Constructor with parameters
    def __init__(self, id_, date, name, type_, fee_paid):
        self.__id = id_
        self.__date = date
        self.__name = name
        self.__type = type_
        self.__fee_paid = fee_paid
        # Initially the Participation Cancellation Date will be empty.
        self.__cancel_date = None

    # Fields access methods (setters & getters)
    def get_id(self):
        return self.__id

    def get_fee_paid(self):
        return self.__fee_paid

    def get_type(self):
        return self.__type

    def get_name(self):
        return self.__name

    def set_name(self, name):
        self.__name = name

    def set_type(self, type_):
        self.__type = type_

    def set_fee_paid(self, fee_paid):
        self.__fee_paid = fee_paid

    def set_cancel_date(self, cancel_date):
        self.__cancel_date = cancel_date

    def get_cancel_date(self):
        return self.__cancel_date

    # Get a line to write the object to txt file.
    def get_data_for_file(self):
        return f"{self.__id},{self.__date},{self.__name},{self.__type},{self.__fee_paid},{self.__cancel_date}"

    # String representation of the object.
    # It will be called when print a Team instance (function print() ).
    def __str__(self):
        result = f"Team ID: {self.__id}\n"
        result += f"Name: {self.__name}\n"
        result += f"Register date: {self.__date}\n"
        result += f"Type: {self.__type}\n"
        if self.__fee_paid:
            result += f"Fee paid: YES\n"
        else:
            result += f"Fee paid: NO\n"
        if self.__cancel_date:
            result += f"Participation cancel date: {self.__cancel_date}\n"
        return result
