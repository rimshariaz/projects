from user_interface import UserInterface

if __name__ == '__main__':
    main = UserInterface()
    main.start()
